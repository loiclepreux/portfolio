<?php

namespace monApp\core;

use monApp\controllers\pages\pageHomeController;
use monApp\controllers\pages\page404Controller;
use monApp\controllers\pages\pageAboutController;
use monApp\controllers\pages\pageSkillsController;
use monApp\controllers\pages\pageProjectController;
use monApp\controllers\pages\pageContactController;

class dispatcher{
    public function dispatch($route){
        if(!$route){
            $this->sendNotFound();
        }else{
            // [$controllerName,$method] = explode("@",$route);
            // $controller = new $controllerName();
            // $controller->$method();

            list($controllerName, $method) = explode("@", $route);
            if (!class_exists($controllerName)) {
                $class = str_replace("monApp\\", "", $controllerName);
                $class = str_replace("\\", "/", $class);
                $file = dirname(__DIR__) . "/" . $class . ".php";
                if (file_exists($file)) {
                    require_once $file;
                }
            }
            if (!class_exists($controllerName)) {
                throw new \Exception("Controller introuvable : " . $controllerName);
            }
            $controller = new $controllerName();
            $controller->$method();
        }
    }
    public function sendNotFound(){
        header("HTTP/1.0 404 Not Found");
        $controller = new page404Controller();
        $controller->index();
    }
}
